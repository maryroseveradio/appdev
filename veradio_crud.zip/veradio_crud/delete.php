<?php
session_start(); // Start the session

if (isset($_GET["id"])) {
    $id = $_GET["id"];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "veradio_crud";

    $connection = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    $sql = "DELETE FROM clients WHERE id=$id";
    if ($connection->query($sql) === TRUE) {
        // Set success message in session
        $_SESSION['successMessage'] = "Client deleted successfully.";
    } else {
        // Optionally, you can set an error message
        $_SESSION['errorMessage'] = "Error deleting client: " . $connection->error;
    }

    $connection->close(); // Close the connection
}

header("location: /veradio_crud/index.php");
exit;
?>